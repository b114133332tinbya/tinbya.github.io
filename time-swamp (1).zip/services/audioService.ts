// This service acts as a "Code-based Synthesizer".
// Instead of playing an MP3, it generates a specific, composed piece of music 
// ("Swamp Lullaby" in C Minor) using oscillators in real-time.
// This ensures high musicality while keeping the file size to zero.

class SwampMusicEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isPlaying = false;
  
  // Effects
  private reverbNode: ConvolverNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayGain: GainNode | null = null;

  // Scheduling
  private nextNoteTime = 0;
  private current16thNote = 0;
  private tempo = 80; // BPM
  private lookahead = 25.0; // milliseconds
  private scheduleAheadTime = 0.1; // seconds
  private timerID: number | null = null;

  // --- Music Theory Data (C Minor) ---
  // Frequencies for notes
  private N = {
    C2: 65.41, D2: 73.42, Eb2: 77.78, F2: 87.31, G2: 98.00, Ab2: 103.83, Bb2: 116.54,
    C3: 130.81, Eb3: 155.56, F3: 174.61, G3: 196.00, Ab3: 207.65, Bb3: 233.08,
    C4: 261.63, D4: 293.66, Eb4: 311.13, F4: 349.23, G4: 392.00, Ab4: 415.30, Bb4: 466.16, B4: 493.88,
    C5: 523.25, D5: 587.33, Eb5: 622.25, F5: 698.46, G5: 783.99,
    // Higher notes for SFX
    C6: 1046.50, E6: 1318.51, G6: 1567.98, C7: 2093.00
  };

  init() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();
    }
  }

  async start() {
    this.init();
    if (!this.ctx) return;

    // Browser Auto-play policy handling:
    // If state is suspended, we try to resume. If it fails (no interaction),
    // it stays suspended until the user clicks something, but we set isPlaying true
    // so the scheduler is ready to go.
    if (this.ctx.state === 'suspended') {
      try {
        await this.ctx.resume();
      } catch (e) {
        console.log("Auto-play prevented. Waiting for user interaction.");
      }
    }

    if (this.isPlaying) return;
    this.isPlaying = true;

    // Master Volume
    if (!this.masterGain) {
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = 0.5;
        this.masterGain.connect(this.ctx.destination);
    }

    // Setup Effects (Reverb + Delay for that "Magical" feel)
    if (!this.reverbNode) {
        await this.setupEffects();
    }

    // Start Scheduling
    this.nextNoteTime = this.ctx.currentTime + 0.1;
    this.current16thNote = 0;
    
    // Clear any existing timer to prevent double loops
    if (this.timerID) window.clearTimeout(this.timerID);
    
    this.scheduler();
  }

  stop() {
    this.isPlaying = false;
    if (this.timerID) window.clearTimeout(this.timerID);
    
    if (this.masterGain && this.ctx) {
      // Fade out nicely
      const now = this.ctx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
      this.masterGain.gain.linearRampToValueAtTime(0, now + 1);
      
      setTimeout(() => {
        if (this.ctx?.state === 'running') this.ctx.suspend();
        // Reset gain for next start
        if(this.masterGain) this.masterGain.gain.value = 0.5; 
      }, 1000);
    }
  }

  // --- Sound Effects (SFX) ---

  playCorrectSound() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const now = this.ctx.currentTime;
    const notes = [this.N.C6, this.N.E6, this.N.G6, this.N.C7];
    
    notes.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        
        osc.type = 'sine';
        osc.frequency.value = freq;
        
        gain.gain.setValueAtTime(0, now + i * 0.08);
        gain.gain.linearRampToValueAtTime(0.1, now + i * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.5);
        
        osc.connect(gain);
        gain.connect(this.masterGain!); 
        if (this.reverbNode) gain.connect(this.reverbNode);

        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.6);
    });
  }

  playIncorrectSound() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const now = this.ctx.currentTime;
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.4);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, now);
    filter.frequency.linearRampToValueAtTime(100, now + 0.4);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.5);
  }

  playTimesUpSound() {
    // A deep, resonant gong/bell sound
    this.init();
    if (!this.ctx || !this.masterGain) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const now = this.ctx.currentTime;
    
    // Fundamental tone + harmonics
    const freqs = [this.N.C2, this.N.G2, this.N.C3]; 
    
    freqs.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        
        // Mix sine and triangle for a metallic sound
        osc.type = i === 0 ? 'sine' : 'triangle'; 
        osc.frequency.value = freq;

        // Long decay
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.4 / (i+1), now + 0.05); // Attack
        gain.gain.exponentialRampToValueAtTime(0.001, now + 3.0); // 3 seconds fade

        osc.connect(gain);
        gain.connect(this.masterGain!);
        // Heavy Reverb
        if (this.reverbNode) {
            const send = this.ctx!.createGain();
            send.gain.value = 0.8;
            gain.connect(send);
            send.connect(this.reverbNode);
        }

        osc.start(now);
        osc.stop(now + 3.5);
    });
  }

  // --- The Core Scheduler ---
  private scheduler() {
    if (!this.isPlaying || !this.ctx) return;

    while (this.nextNoteTime < this.ctx.currentTime + this.scheduleAheadTime) {
      this.scheduleNote(this.current16thNote, this.nextNoteTime);
      this.nextStep();
    }

    this.timerID = window.setTimeout(() => this.scheduler(), this.lookahead);
  }

  private nextStep() {
    const secondsPerBeat = 60.0 / this.tempo;
    this.nextNoteTime += 0.25 * secondsPerBeat; 
    this.current16thNote++;
    if (this.current16thNote === 64) { 
      this.current16thNote = 0;
    }
  }

  // --- Composition: The "Score" ---
  private scheduleNote(beatIndex: number, time: number) {
    if (!this.ctx) return;

    // Chord Progression: Cm | Ab | Fm | G7
    // === 1. Bass Line (Deep & Slow) ===
    if (beatIndex === 0) this.playBass(time, this.N.C2);
    if (beatIndex === 16) this.playBass(time, this.N.Ab2);
    if (beatIndex === 32) this.playBass(time, this.N.F2);
    if (beatIndex === 48) this.playBass(time, this.N.G2);

    // === 2. Arpeggio / Chords (The Harmony) ===
    if (beatIndex % 4 === 0) {
      if (beatIndex < 16) { // Cm
        this.playPad(time, this.N.C3);
        this.playPad(time + 0.1, this.N.Eb3);
        this.playPad(time + 0.2, this.N.G3);
      } else if (beatIndex < 32) { // Ab
        this.playPad(time, this.N.Ab3);
        this.playPad(time + 0.1, this.N.C4);
        this.playPad(time + 0.2, this.N.Eb4);
      } else if (beatIndex < 48) { // Fm
        this.playPad(time, this.N.F3);
        this.playPad(time + 0.1, this.N.Ab3);
        this.playPad(time + 0.2, this.N.C4);
      } else { // G7
        this.playPad(time, this.N.G3);
        this.playPad(time + 0.1, this.N.B4);
        this.playPad(time + 0.2, this.N.D4);
      }
    }

    // === 3. Melody (The "Harp" Lead) ===
    const melodyPattern: {[key: number]: number} = {
        // Bar 1 (Cm)
        0: this.N.G4, 4: this.N.C5, 10: this.N.Eb5, 12: this.N.D5, 14: this.N.C5,
        // Bar 2 (Ab)
        16: this.N.Eb5, 20: this.N.C5, 26: this.N.Ab4, 28: this.N.G4, 30: this.N.Ab4,
        // Bar 3 (Fm)
        32: this.N.F5, 36: this.N.C5, 42: this.N.Ab4, 44: this.N.G4, 46: this.N.F4,
        // Bar 4 (G7) - Tension
        48: this.N.D5, 52: this.N.B4, 58: this.N.G4, 60: this.N.F4, 62: this.N.D4
    };

    if (melodyPattern[beatIndex]) {
        const humanize = (Math.random() * 0.02) - 0.01; 
        this.playHarp(time + humanize, melodyPattern[beatIndex]);
    }
  }

  // --- Instruments ---
  private playHarp(time: number, freq: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine'; 
    osc.frequency.setValueAtTime(freq, time);
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.3, time + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 1.5);
    osc.connect(gain);
    gain.connect(this.masterGain);
    if (this.delayNode && this.reverbNode) {
        gain.connect(this.delayNode);
        gain.connect(this.reverbNode);
    }
    osc.start(time);
    osc.stop(time + 1.6);
  }

  private playPad(time: number, freq: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, time);
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, time);
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.05, time + 0.5);
    gain.gain.linearRampToValueAtTime(0, time + 2.0);
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    if (this.reverbNode) gain.connect(this.reverbNode);
    osc.start(time);
    osc.stop(time + 2.1);
  }

  private playBass(time: number, freq: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine'; 
    osc.frequency.setValueAtTime(freq, time);
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.3, time + 0.1);
    gain.gain.linearRampToValueAtTime(0, time + 3.0); 
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(time);
    osc.stop(time + 3.1);
  }

  // --- Effects Setup ---
  private async setupEffects() {
    if (!this.ctx || !this.masterGain) return;
    // 1. Reverb
    this.reverbNode = this.ctx.createConvolver();
    this.reverbNode.buffer = await this.createReverbImpulse(3); 
    const reverbMix = this.ctx.createGain();
    reverbMix.gain.value = 0.4; 
    this.reverbNode.connect(reverbMix);
    reverbMix.connect(this.masterGain);

    // 2. Delay
    this.delayNode = this.ctx.createDelay();
    this.delayNode.delayTime.value = 0.5; 
    this.delayGain = this.ctx.createGain();
    this.delayGain.gain.value = 0.3; 
    this.delayNode.connect(this.delayGain);
    this.delayGain.connect(this.delayNode); 
    this.delayGain.connect(this.masterGain);
  }

  private createReverbImpulse(duration: number): AudioBuffer {
    if (!this.ctx) throw new Error("No Context");
    const rate = this.ctx.sampleRate;
    const length = rate * duration;
    const impulse = this.ctx.createBuffer(2, length, rate);
    const L = impulse.getChannelData(0);
    const R = impulse.getChannelData(1);
    for (let i = 0; i < length; i++) {
        const n = i / length;
        const decay = Math.pow(1 - n, 2); 
        L[i] = (Math.random() * 2 - 1) * decay;
        R[i] = (Math.random() * 2 - 1) * decay;
    }
    return impulse;
  }
}

export const audioService = new SwampMusicEngine();
