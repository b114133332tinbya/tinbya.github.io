import React from 'react';

const SwampBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 w-full h-full overflow-hidden -z-10 bg-slate-900">
      {/* Deep Gradient Sky */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-purple-950 to-emerald-950 opacity-90"></div>

      {/* Stars */}
      <div className="absolute inset-0">
        {[...Array(30)].map((_, i) => (
          <div
            key={`star-${i}`}
            className="absolute rounded-full bg-white animate-pulse"
            style={{
              top: `${Math.random() * 50}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 3 + 1}px`,
              height: `${Math.random() * 3 + 1}px`,
              opacity: Math.random() * 0.7 + 0.3,
              animationDuration: `${Math.random() * 3 + 2}s`
            }}
          />
        ))}
      </div>

      {/* Fog Layers */}
      <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-emerald-900/40 to-transparent animate-pulse delay-700"></div>
      <div className="absolute bottom-0 left-0 w-full h-64 bg-slate-900/30 blur-xl"></div>

      {/* Fireflies */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={`firefly-${i}`}
            className="absolute w-1 h-1 bg-yellow-300 rounded-full shadow-[0_0_8px_2px_rgba(253,224,71,0.6)]"
            style={{
              top: `${Math.random() * 60 + 40}%`,
              left: `${Math.random() * 100}%`,
              animation: `float ${Math.random() * 10 + 10}s infinite ease-in-out alternate`,
              opacity: 0.8
            }}
          />
        ))}
      </div>
      
      {/* CSS for custom float animation */}
      <style>{`
        @keyframes float {
          0% { transform: translate(0, 0); opacity: 0; }
          20% { opacity: 0.8; }
          50% { transform: translate(${Math.random() * 40 - 20}px, ${Math.random() * -40}px); }
          80% { opacity: 0.8; }
          100% { transform: translate(${Math.random() * 60 - 30}px, ${Math.random() * -60}px); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default SwampBackground;
