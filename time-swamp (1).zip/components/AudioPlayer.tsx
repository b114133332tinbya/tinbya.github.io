import React, { useState, useEffect, useCallback } from 'react';
import { audioService } from '../services/audioService';

const AudioPlayer: React.FC = () => {
  // Default to true (user wants music)
  const [isPlaying, setIsPlaying] = useState(true);

  // Try to start immediately on mount
  useEffect(() => {
    const initAudio = async () => {
      // attempt to start
      await audioService.start();
    };

    initAudio();

    // Browser policy: If AudioContext is blocked (suspended) due to no interaction,
    // we listen for the FIRST click anywhere on the page to unlock it.
    const unlockAudio = async () => {
      await audioService.start();
      // Remove listener once we've tried to unlock
      document.removeEventListener('click', unlockAudio);
      document.removeEventListener('keydown', unlockAudio);
    };

    document.addEventListener('click', unlockAudio);
    document.addEventListener('keydown', unlockAudio);

    return () => {
      document.removeEventListener('click', unlockAudio);
      document.removeEventListener('keydown', unlockAudio);
    };
  }, []);

  const toggleAudio = useCallback(async () => {
    if (isPlaying) {
      audioService.stop();
      setIsPlaying(false);
    } else {
      await audioService.start();
      setIsPlaying(true);
    }
  }, [isPlaying]);

  return (
    <button
      onClick={toggleAudio}
      className="fixed top-4 right-4 z-50 flex items-center justify-center p-3 text-emerald-200 transition-all duration-300 bg-black/40 border border-emerald-500/30 rounded-full backdrop-blur-md hover:bg-emerald-900/50 hover:text-white group"
      aria-label={isPlaying ? "Stop Music" : "Play Music"}
    >
      {isPlaying ? (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-pulse">
          <rect x="6" y="4" width="4" height="16"></rect>
          <rect x="14" y="4" width="4" height="16"></rect>
        </svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="group-hover:scale-110 transition-transform">
          <path d="M9 18V5l12-2v13"></path>
          <circle cx="6" cy="18" r="3"></circle>
          <circle cx="18" cy="16" r="3"></circle>
        </svg>
      )}
      <span className="ml-2 text-sm font-medium hidden sm:inline">
        {isPlaying ? "Pause Music" : "Play Music"}
      </span>
    </button>
  );
};

export default AudioPlayer;